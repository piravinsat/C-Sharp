﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MoonDefense
{
    class ResourceManager
    {
        private ContentManager contentManager;

        public static Texture2D playerTexture;
        public static Texture2D playerCarryingTexture;
        public static Texture2D bulletTexture;
        public static Texture2D lifebarRedSprite;
        public static Texture2D lifebarGreenSprite;
        //Some of these need renaming :/
        public static Texture2D tile1;
        public static Texture2D tile2;
        public static Texture2D tile3;
        public static Texture2D tile4;
        public static Texture2D tile5;
        public static Texture2D tile6;
        public static Texture2D tile7;
        public static Texture2D spawnerAnimation;
        public static Texture2D baseTexture;
        public static Texture2D exampleTower;
        public static Texture2D electricTower;
        public static Texture2D turretTower;
        public static Texture2D sniperTower;
        public static Texture2D needleTower;
        public static Texture2D waterTower;
        public static Texture2D mob;
        public static Texture2D theEyeMob;
        public static Texture2D discoStuMob;
        public static Texture2D upgradeTexture;
        public static Texture2D levelTexture;
        public static Texture2D laserBeam;
        public static Texture2D electricBullet;
        public static SpriteFont spriteFont;

        public ResourceManager(ContentManager contentManager)
        {
            this.contentManager = contentManager;
            LoadSprites();
        }

        private void LoadSprites()
        {
            playerTexture = contentManager.Load<Texture2D>("man");
            playerCarryingTexture = contentManager.Load<Texture2D>("mancarryingsomething");
            bulletTexture = contentManager.Load<Texture2D>("bullet");
            lifebarGreenSprite = contentManager.Load<Texture2D>("lifebar_green");
            lifebarRedSprite = contentManager.Load<Texture2D>("lifebar_red");
            tile1 = contentManager.Load<Texture2D>("tile1");
            tile2 = contentManager.Load<Texture2D>("tile2");
            tile3 = contentManager.Load<Texture2D>("MoonCrater");
            tile4 = contentManager.Load<Texture2D>("BlankTile");
            tile5 = contentManager.Load<Texture2D>("FootprintTile");
            tile6 = contentManager.Load<Texture2D>("HugeCrater");
            tile7 = contentManager.Load<Texture2D>("Beagle2");
            spawnerAnimation = contentManager.Load<Texture2D>("spawnerAnimation");
            baseTexture = contentManager.Load<Texture2D>("base");
            exampleTower = contentManager.Load<Texture2D>("tower");
            electricTower = contentManager.Load<Texture2D>("electricTower");
            turretTower = contentManager.Load<Texture2D>("Turret");
            sniperTower = contentManager.Load<Texture2D>("Tower3");
            needleTower = contentManager.Load<Texture2D>("SpaceNeedleTower");
            waterTower = contentManager.Load<Texture2D>("WaterTower");
            mob = contentManager.Load<Texture2D>("SpaceHooper");
            theEyeMob = contentManager.Load<Texture2D>("TheEye");
            discoStuMob = contentManager.Load<Texture2D>("DiscoStu");
            upgradeTexture = contentManager.Load<Texture2D>("upgrade");
            levelTexture = contentManager.Load<Texture2D>("level");
            laserBeam = contentManager.Load<Texture2D>("laserbeam");
            electricBullet = contentManager.Load<Texture2D>("electric_bullet");
            spriteFont = contentManager.Load<SpriteFont>("SpriteFont1");
        }
    }
}
